Miniweb SSL Certifcate folder

In this folder, you can place your server certificate and private key for SSL Connections.
These files must be named Cert.cer for the Certificate and Key.pem for the Private Key.
File Format is PEM Format.

If these files are not found ,the Miniweb server creates a self-signed certificate with 
the corresponding private key on the first https access, and stores it as cert.cer and key.pem
files in this directory.
